-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_notification`
--

DROP TABLE IF EXISTS `insta_tbl_notification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_notification` (
  `NOTI_ID` int NOT NULL AUTO_INCREMENT COMMENT '알림 고유 ID',
  `RECEIVER_ID` varchar(300) NOT NULL COMMENT '알림을 받는 사용자 ID',
  `SENDER_ID` varchar(300) NOT NULL COMMENT '알림을 발생시킨 사용자 ID',
  `NOTI_TYPE` varchar(20) NOT NULL COMMENT '알림 타입 (LIKE, COMMENT, FOLLOW 등)',
  `TARGET_ID` int DEFAULT NULL COMMENT '알림 대상 (Feed ID, Comment ID 등 - Nullable)',
  `IS_READ` tinyint(1) DEFAULT '0' COMMENT '읽음 여부',
  `CREATED_AT` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '생성 일시',
  PRIMARY KEY (`NOTI_ID`),
  KEY `RECEIVER_ID` (`RECEIVER_ID`),
  KEY `SENDER_ID` (`SENDER_ID`),
  CONSTRAINT `insta_tbl_notification_ibfk_1` FOREIGN KEY (`RECEIVER_ID`) REFERENCES `insta_tbl_user` (`USER_ID`),
  CONSTRAINT `insta_tbl_notification_ibfk_2` FOREIGN KEY (`SENDER_ID`) REFERENCES `insta_tbl_user` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_notification`
--

LOCK TABLES `insta_tbl_notification` WRITE;
/*!40000 ALTER TABLE `insta_tbl_notification` DISABLE KEYS */;
/*!40000 ALTER TABLE `insta_tbl_notification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:08
