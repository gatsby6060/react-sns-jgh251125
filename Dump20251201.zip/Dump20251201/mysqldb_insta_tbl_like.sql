-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_like`
--

DROP TABLE IF EXISTS `insta_tbl_like`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_like` (
  `FEED_ID` int NOT NULL COMMENT '게시물 ID',
  `USER_ID` varchar(300) NOT NULL COMMENT '좋아요 누른 사용자 ID',
  `CREATED_AT` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`FEED_ID`,`USER_ID`),
  KEY `USER_ID` (`USER_ID`),
  CONSTRAINT `insta_tbl_like_ibfk_1` FOREIGN KEY (`FEED_ID`) REFERENCES `insta_tbl_feed` (`FEED_ID`),
  CONSTRAINT `insta_tbl_like_ibfk_2` FOREIGN KEY (`USER_ID`) REFERENCES `insta_tbl_user` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_like`
--

LOCK TABLES `insta_tbl_like` WRITE;
/*!40000 ALTER TABLE `insta_tbl_like` DISABLE KEYS */;
INSERT INTO `insta_tbl_like` VALUES (11,'kakao_4501469156_kakao','2025-12-01 14:33:04'),(12,'일이삼사','2025-11-28 18:07:03'),(13,'kakao_4501469156_kakao','2025-12-01 17:00:06'),(13,'일이삼사','2025-11-28 18:13:30'),(14,'닉네임전경환1234','2025-12-01 17:47:18'),(14,'일이삼사','2025-12-01 13:09:19'),(16,'kakao_4501469156_kakao','2025-12-01 14:32:57'),(16,'닉네임전경환1234','2025-12-01 17:47:17'),(17,'kakao_4501469156_kakao','2025-12-01 16:40:41'),(17,'닉네임전경환1234','2025-12-01 17:47:16'),(19,'닉네임전경환1234','2025-12-01 17:47:08'),(20,'닉네임전경환1234','2025-12-01 17:47:09'),(22,'닉네임전경환1234','2025-12-01 17:47:11');
/*!40000 ALTER TABLE `insta_tbl_like` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:08
