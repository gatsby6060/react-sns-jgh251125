-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_user`
--

DROP TABLE IF EXISTS `tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_user` (
  `userId` varchar(50) NOT NULL,
  `pwd` varchar(500) NOT NULL,
  `userName` varchar(50) NOT NULL,
  `addr` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `cdatetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `udatetime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `follower` int DEFAULT '0',
  `following` int DEFAULT '0',
  `intro` varchar(300) DEFAULT '안녕하세요?',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_user`
--

LOCK TABLES `tbl_user` WRITE;
/*!40000 ALTER TABLE `tbl_user` DISABLE KEYS */;
INSERT INTO `tbl_user` VALUES ('1','$2b$10$6tW2ivf6VhPNaiwTqXoN2O4EDK9tSA7/H1bGahs/0JSzpQ5KPu48u','',NULL,NULL,'2025-11-14 17:45:14','2025-11-14 17:45:14',0,0,'안녕하세요?'),('123','123','일이삼',NULL,NULL,'2025-11-14 17:41:39','2025-11-14 17:41:39',0,0,'안녕하세요?'),('2','$2b$10$sLM8cnru5QXDs4UXnm4d5O8aqinI3q4.ZQNkCv742uXG2Bp0TLu2e','',NULL,NULL,'2025-11-14 17:47:47','2025-11-14 17:47:47',0,0,'안녕하세요?'),('gg1','$2b$10$UjTf3xzs/URfjmG9axRlc.PbQc53UaiwisaDhOBz2j3dR3SXuKFmG','일이삼사',NULL,NULL,'2025-11-21 12:45:33','2025-11-21 12:45:33',0,0,'안녕하세요?'),('gg2','$2b$10$4KPQ1lLstWU73soPV3h1oeuE5YrCRLtdHx.42QPijYBe//W6wBWfS','1234',NULL,NULL,'2025-11-21 12:46:12','2025-11-21 12:46:12',0,0,'안녕하세요?'),('gogle','1234','구글인',NULL,NULL,'2025-11-21 12:35:26','2025-11-21 12:35:26',0,0,'안녕하세요?'),('idid123','$2b$10$3LGlXb35EfvA9Q0uQjfcleqvPOAsiZV3TLUQ5VeiwjvynDnK5QBOa','일이삼',NULL,NULL,'2025-11-21 13:06:18','2025-11-21 13:06:18',0,0,'안녕하세요?'),('k1','$2b$10$FyV/GA8Xvy5Oy3EZqgm8SO.UjKzYZw.k3F3bIyrbvVC0C8gnHth8i','케이원케이원',NULL,NULL,'2025-11-21 13:07:16','2025-11-21 13:07:16',0,0,'안녕하세요?'),('qqq','$2b$10$PwhayNl.wDAtFf22Lmk3OeQjYQsnpJF8/lobf8M9NYVocNk1sRK8.','일이삼사',NULL,NULL,'2025-11-21 13:01:56','2025-11-21 13:01:56',0,0,'안녕하세요?'),('qqq2','$2b$10$Ntl0X5vTryd6pY2w2VfvxuX7ahBMCx03Vl8jVO25QGk71NJoGDsNO','일이삼',NULL,NULL,'2025-11-21 13:05:49','2025-11-21 13:05:49',0,0,'안녕하세요?'),('qw1212','$2b$10$hWaaRrhOwuY.tugU1hGMrel9f5CnxHnjP36z3EfjuqRVGDlU1Nu/6','일이일이',NULL,NULL,'2025-11-21 13:03:56','2025-11-21 13:03:56',0,0,'안녕하세요?'),('qw123','$2b$10$bLJcH8jwbXXe6uTFhYmEZO9AiYjGEs0Q9x2NgHyxV4dJJ27ZzwEem','큐w일이삼',NULL,NULL,'2025-11-21 16:24:04','2025-11-21 16:24:04',0,0,'안녕하세요?'),('test1','$2b$10$2popj1XDsjhHCZAIa/suteenSZd4kY.3ESqLKWOrCSB5N5EQhBbiO','테스트일',NULL,NULL,'2025-11-21 15:58:02','2025-11-21 15:58:40',0,0,'안녕하세요?'),('test123','$2b$10$GtC0LWEh4IIhCKF9QZCfdeqfurBbjUMNvlh9/09k6Nlqify/KC5a2','일이삼사',NULL,NULL,'2025-11-14 17:49:54','2025-11-14 17:49:54',0,0,'안녕하세요?'),('ttt','$2b$10$.QrC6N1SEmQVbBv9AHEk9uEs7momOpMPNZL7wcTNSqNq2HPCOLtCK','일이삼사',NULL,NULL,'2025-11-14 17:42:40','2025-11-14 17:42:40',0,0,'안녕하세요?'),('user001','pwd1','홍길동','서울','010-1111-2222','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user002','pwd2','김철수','인천','010-2233-4455','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user003','pwd3','이영희','대전','010-3344-5566','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user004','pwd4','박지민','광주','010-4455-6677','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user005','pwd5','최민수','서울','010-5566-7788','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user006','pwd6','정수진','부산','010-6677-8899','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user007','pwd7','김하늘','인천','010-7788-9900','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user008','pwd8','이상훈','울산','010-8899-1000','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user009','pwd9','박세영','대구','010-9900-1111','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?'),('user010','pwd10','정예린','경기','010-1001-1222','2025-11-14 11:13:07','2025-11-14 11:13:07',0,0,'안녕하세요?');
/*!40000 ALTER TABLE `tbl_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:07
