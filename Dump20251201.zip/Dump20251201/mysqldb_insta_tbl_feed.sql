-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_feed`
--

DROP TABLE IF EXISTS `insta_tbl_feed`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_feed` (
  `FEED_ID` int NOT NULL AUTO_INCREMENT COMMENT '게시물 고유 ID',
  `USER_ID` varchar(300) NOT NULL COMMENT '작성자 ID',
  `TITLE` varchar(255) DEFAULT NULL COMMENT '게시물 제목',
  `CONTENT` text NOT NULL COMMENT '게시물 본문',
  `CATEGORY_ID` int DEFAULT NULL COMMENT '주제/취미 카테고리 ID',
  `LOCATION_ID` int DEFAULT NULL COMMENT '게시물 작성 지역 ID',
  `LATITUDE` decimal(10,8) DEFAULT NULL COMMENT '촬영 위치 위도',
  `LONGITUDE` decimal(11,8) DEFAULT NULL COMMENT '촬영 위치 경도',
  `LIKE_COUNT` int DEFAULT '0' COMMENT '좋아요 수 (캐싱용)',
  `CREATED_AT` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '생성 일시',
  PRIMARY KEY (`FEED_ID`),
  KEY `USER_ID` (`USER_ID`),
  KEY `CATEGORY_ID` (`CATEGORY_ID`),
  KEY `LOCATION_ID` (`LOCATION_ID`),
  CONSTRAINT `insta_tbl_feed_ibfk_1` FOREIGN KEY (`USER_ID`) REFERENCES `insta_tbl_user` (`USER_ID`),
  CONSTRAINT `insta_tbl_feed_ibfk_2` FOREIGN KEY (`CATEGORY_ID`) REFERENCES `insta_tbl_category` (`CATEGORY_ID`),
  CONSTRAINT `insta_tbl_feed_ibfk_3` FOREIGN KEY (`LOCATION_ID`) REFERENCES `insta_tbl_location` (`LOCATION_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_feed`
--

LOCK TABLES `insta_tbl_feed` WRITE;
/*!40000 ALTER TABLE `insta_tbl_feed` DISABLE KEYS */;
INSERT INTO `insta_tbl_feed` VALUES (1,'일이삼사','오늘 날씨가 정말 좋네요!','오늘 날씨가 정말 좋네요!',NULL,NULL,NULL,NULL,0,'2024-10-20 00:30:00'),(2,'일이삼사','1234','1234',NULL,NULL,NULL,NULL,0,'2025-11-27 11:33:03'),(3,'일이삼사','1','1',NULL,NULL,NULL,NULL,0,'2025-11-27 11:45:07'),(4,'일이삼사','1','1',NULL,NULL,NULL,NULL,0,'2025-11-27 12:04:09'),(5,'일이삼사','1','1',NULL,NULL,NULL,NULL,0,'2025-11-27 12:05:56'),(6,'일이삼사','123','123',NULL,NULL,NULL,NULL,0,'2025-11-27 12:07:17'),(7,'일일일일','123','123',NULL,NULL,NULL,NULL,0,'2025-11-27 14:36:41'),(8,'일일일일','동영상테스트중','동영상테스트중',NULL,NULL,NULL,NULL,0,'2025-11-27 14:40:19'),(9,'일일일일','mp4테스트','mp4테스트',NULL,NULL,NULL,NULL,0,'2025-11-27 15:46:00'),(10,'일일일일','동영상1개사진2개','동영상1개사진2개',NULL,NULL,NULL,NULL,0,'2025-11-27 16:46:03'),(11,'닉네임전경환1234',NULL,'123',NULL,NULL,NULL,NULL,1,'2025-11-28 12:37:56'),(12,'닉네임전경환1234',NULL,'?전교 1등 비결은 훔친 시험지\n검찰, 모녀 나란히 징역형 구형\n\n- 딸이 다니는 학교에 침입해 시험지를\n상습적으로 빼돌린 혐의로 40대 학부모\nA (48)씨에게 검찰이 징역 8년을 구형\n\n- 또 범행을 도운 기간제 교사 B 씨에 징역\n7년, 행정실장 C(37) 씨에게는 징역 3년을,\nA 씨 딸에게는 장기 3년∼단기 2년을 구형\n\n- 학부모 A 씨는 2023년부터 최근까지 딸이\n재학 중인 경북 안동의 한 고등학교에 무단\n침입해 중간·기말고사 시험지를 빼돌린 혐의\n\n- 이에 A 씨 딸은 고등학교 내신 평가에서 단 한\n번도 전교 1등을 놓치지 않았고 이들의 범행은\n지난 7월 경비 시스템이 오작동하면서 발각\n\n?연합뉴스\n\n?당장 주목해야 할 사회•경제 소식 구독하기\n@attention.point',NULL,NULL,NULL,NULL,1,'2025-11-28 13:03:25'),(13,'일이삼사',NULL,'인천 구월시장 위치 [박가네 구월시장점]\n\n곱창을 제일 맛있게 먹을 수 있는 곳은\n시장 안에 있는 곱창집인 것 같아요.\n\n저는 구월시장에 있는 박가네로 방문했구여\n\n이 집이 가성비가 상당해서\n한우곱창 땡기실 때 가기 좋습니다\n\n구성은 곱창대창막창에 부속고기에 벌양에 염통이\n총 1.3kg!!ㄷㄷ\n\n가격은 54,000원으로 상당히 저렴한 편이고\n\n기본으로 선지해장국에 간 천엽 등등\n밑반찬까지 푸짐하게 잘나와요\n\n8천원짜리 한우내장탕 시키면\n물반 고기반일 정도로\n묵직한 고기양에서\n\n사장님의 시장인심이 팍팍 느껴지고\n\n구월시장 안에 있어서 접근성도 용이하니\n드시러 다녀오시는 것 추천드립니다\n\n#인천맛집 #구월동맛집 #구월시장맛집 #모래네시장맛집',NULL,NULL,NULL,NULL,2,'2025-11-28 13:10:51'),(14,'일이삼사',NULL,'흑인들 키는 크다.',NULL,NULL,NULL,NULL,2,'2025-11-28 16:04:22'),(16,'kakao_4501469156_kakao',NULL,'토끼와 곰이 꽃밭에 있어요',NULL,NULL,NULL,NULL,2,'2025-12-01 13:11:49'),(17,'kakao_4501469156_kakao',NULL,'광어 회뜨기',NULL,NULL,NULL,NULL,2,'2025-12-01 14:38:16'),(18,'kakao_4501469156_kakao',NULL,'1. 일은 어자피 계속 있음 안끝남\n2. 쟤는 왜 맨날 야근하지 ? -> 다 이유가 있음\n3. 쟤는 왜 맨날 칼퇴하지 ? -> 다 이유가 있음\n4. 쟤는 왜 저러지? -> 다 이유가 있음\n5. 쟤는 왜 친절하지? -> 퇴사함\n6. 쟤는 왜 항상 밝고 웃고 있지? -> 곧 퇴사함\n',NULL,NULL,NULL,NULL,0,'2025-12-01 17:04:40'),(19,'kakao_4501469156_kakao',NULL,'내용테스트',NULL,NULL,NULL,NULL,1,'2025-12-01 17:07:52'),(20,'kakao_4501469156_kakao',NULL,'내용테스트중',NULL,NULL,NULL,NULL,1,'2025-12-01 17:35:56'),(22,'닉네임전경환1234','피드등록관련 제목 테스트','피드등록관련 내용부분 테스트\n신동엽 나와요',NULL,NULL,NULL,NULL,1,'2025-12-01 17:42:52');
/*!40000 ALTER TABLE `insta_tbl_feed` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:07
