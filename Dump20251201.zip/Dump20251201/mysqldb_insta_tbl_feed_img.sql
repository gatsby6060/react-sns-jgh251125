-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_feed_img`
--

DROP TABLE IF EXISTS `insta_tbl_feed_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_feed_img` (
  `imgNo` int NOT NULL AUTO_INCREMENT,
  `feedId` varchar(500) NOT NULL,
  `imgName` varchar(500) NOT NULL,
  `imgPath` varchar(500) NOT NULL,
  `mediaType` enum('image','video') NOT NULL DEFAULT 'image' COMMENT '미디어 파일 유형: image 또는 video',
  PRIMARY KEY (`imgNo`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_feed_img`
--

LOCK TABLES `insta_tbl_feed_img` WRITE;
/*!40000 ALTER TABLE `insta_tbl_feed_img` DISABLE KEYS */;
INSERT INTO `insta_tbl_feed_img` VALUES (1,'1','test','https://images.unsplash.com/photo-1551963831-b3b1ca40c98e','image'),(2,'1','test','http://localhost:3010/uploads/1763970428789-hat.jfif','image'),(3,'5','1764212757433-img05.jpg','http://localhost:3010/uploads/1764212757433-img05.jpg','image'),(4,'6','1764212839176-img04.png','http://localhost:3010/uploads/1764212839176-img04.png','image'),(5,'6','1764212839179-img02.jpg','http://localhost:3010/uploads/1764212839179-img02.jpg','image'),(6,'7','1764221802350-woman.png','http://localhost:3010/uploads/1764221802350-woman.png','image'),(7,'7','1764221802352-man.png','http://localhost:3010/uploads/1764221802352-man.png','image'),(8,'8','1764222021003-2025-11-27 14-38-57.mkv','http://localhost:3010/uploads/1764222021003-2025-11-27 14-38-57.mkv','image'),(9,'9','1764225961561-2025-11-27 15-29-09.mp4','http://localhost:3010/uploads/1764225961561-2025-11-27 15-29-09.mp4','video'),(10,'10','1764229564959-2025-11-27 15-29-09.mp4','http://localhost:3010/uploads/1764229564959-2025-11-27 15-29-09.mp4','video'),(11,'10','1764229564986-woman.png','http://localhost:3010/uploads/1764229564986-woman.png','image'),(12,'10','1764229564986-man.png','http://localhost:3010/uploads/1764229564986-man.png','image'),(13,'11','1764301077841-KakaoTalk_20251107_111825472.mp4','http://localhost:3010/uploads/1764301077841-KakaoTalk_20251107_111825472.mp4','video'),(14,'12','1764302606859-si.png','http://localhost:3010/uploads/1764302606859-si.png','image'),(15,'13','1764303052715-2025-11-28 13 09 32.mp4','http://localhost:3010/uploads/1764303052715-2025-11-28 13 09 32.mp4','video'),(16,'14','1764313463693-2025-11-28 12 58 40.mp4','http://localhost:3010/uploads/1764313463693-2025-11-28 12 58 40.mp4','video'),(17,'15','1764562253788-selectedCherry.jpg','http://localhost:3010/uploads/1764562253788-selectedCherry.jpg','image'),(18,'16','1764562310905-test4.jfif','http://localhost:3010/uploads/1764562310905-test4.jfif','image'),(19,'17','1764567498262-2025-12-01 14 12 22.mp4','http://localhost:3010/uploads/1764567498262-2025-12-01 14 12 22.mp4','video'),(20,'18','1764576281487-test.png','http://localhost:3010/uploads/1764576281487-test.png','image'),(21,'19','1764576473812-test.png','http://localhost:3010/uploads/1764576473812-test.png','image'),(22,'20','1764578157970-2025-12-01 14 14 14.mp4','http://localhost:3010/uploads/1764578157970-2025-12-01 14 14 14.mp4','video'),(23,'21','1764578318027-2025-11-28 13 00 12.mp4','http://localhost:3010/uploads/1764578318027-2025-11-28 13 00 12.mp4','video'),(24,'22','1764578573586-2025-12-01 14 14 14.mp4','http://localhost:3010/uploads/1764578573586-2025-12-01 14 14 14.mp4','video');
/*!40000 ALTER TABLE `insta_tbl_feed_img` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:09
