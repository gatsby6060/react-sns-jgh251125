-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_chat_message`
--

DROP TABLE IF EXISTS `insta_tbl_chat_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_chat_message` (
  `MESSAGE_ID` int NOT NULL AUTO_INCREMENT COMMENT '메시지 고유 ID',
  `ROOM_ID` int NOT NULL COMMENT '채팅방 ID',
  `SENDER_ID` varchar(300) NOT NULL COMMENT '발신자 ID',
  `CONTENT` text COMMENT '메시지 내용 (텍스트)',
  `MEDIA_URL` varchar(255) DEFAULT NULL COMMENT '미디어 파일 URL (사진, 영상 등)',
  `MESSAGE_TYPE` varchar(10) NOT NULL DEFAULT 'TEXT' COMMENT '메시지 타입 (TEXT, IMAGE, VIDEO)',
  `IS_READ` tinyint(1) DEFAULT '0' COMMENT '수신자가 읽었는지 여부 (0: 안 읽음, 1: 읽음)',
  `CREATED_AT` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '전송 일시',
  PRIMARY KEY (`MESSAGE_ID`),
  KEY `ROOM_ID` (`ROOM_ID`),
  KEY `SENDER_ID` (`SENDER_ID`),
  CONSTRAINT `insta_tbl_chat_message_ibfk_1` FOREIGN KEY (`ROOM_ID`) REFERENCES `insta_tbl_chat_room` (`ROOM_ID`),
  CONSTRAINT `insta_tbl_chat_message_ibfk_2` FOREIGN KEY (`SENDER_ID`) REFERENCES `insta_tbl_user` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_chat_message`
--

LOCK TABLES `insta_tbl_chat_message` WRITE;
/*!40000 ALTER TABLE `insta_tbl_chat_message` DISABLE KEYS */;
/*!40000 ALTER TABLE `insta_tbl_chat_message` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:07
