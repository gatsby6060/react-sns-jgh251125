-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_user`
--

DROP TABLE IF EXISTS `insta_tbl_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_user` (
  `USER_ID` varchar(300) NOT NULL COMMENT '사용자 ID (소셜 로그인 대비 300자)',
  `PASSWORD` varchar(255) NOT NULL COMMENT '비밀번호 (해시값)',
  `USERNAME` varchar(100) NOT NULL COMMENT '사용자 이름 (표시 이름)',
  `EMAILORPHONE` varchar(255) DEFAULT NULL,
  `REGION_ID` int DEFAULT NULL COMMENT '거주 지역 ID',
  `HOBBIES` json DEFAULT NULL COMMENT '관심 취미 목록 (JSON 배열)',
  `PROFILE_IMG` varchar(255) DEFAULT NULL COMMENT '프로필 사진 URL',
  `INTRO` text COMMENT '자기소개',
  `CREATED_AT` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '생성 일시',
  PRIMARY KEY (`USER_ID`),
  UNIQUE KEY `EMAIL` (`EMAILORPHONE`),
  KEY `REGION_ID` (`REGION_ID`),
  CONSTRAINT `insta_tbl_user_ibfk_1` FOREIGN KEY (`REGION_ID`) REFERENCES `insta_tbl_location` (`LOCATION_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_user`
--

LOCK TABLES `insta_tbl_user` WRITE;
/*!40000 ALTER TABLE `insta_tbl_user` DISABLE KEYS */;
INSERT INTO `insta_tbl_user` VALUES ('1q2w3e4r','$2b$10$Fva3fGh98nH64gBcObeZpudYPlU5LKuNQglbeZfZ/iV.l0udZgFey','김순이','01012341234',NULL,NULL,NULL,NULL,'2025-11-28 09:54:47'),('kakao_4501469156_kakao','','전경환','',NULL,NULL,'http://k.kakaocdn.net/dn/tX2ct/btsNFrBNt4H/i1rVJs82YYSZAYoXi7h0sk/img_640x640.jpg','123','2025-12-01 09:37:28'),('닉공일구','$2b$10$MgJZrnTs8PSgYapvX.2rA.7h5Jh/E1GZ.XFy9WodhXSOjkYrLWQ/i','공일구','01912341234',NULL,NULL,NULL,NULL,'2025-11-27 17:19:29'),('닉네임전경환1234','$2b$10$zHMLNCliYHFWGQqrbJLareWaGDB5y62u13TvBDmuZVyomymrUD83a','전경환','01071252266',NULL,NULL,'http://localhost:3010/uploads/1764301055809-sata.png',NULL,'2025-11-26 12:49:04'),('순이1234','$2b$10$oU9MuuiBmw2nqReyhC2Ms.Poio8wRnjWuVsk6h3c0BLGHxvu05jTm','김순이','aj1999@hanmail.net',NULL,NULL,NULL,NULL,'2025-11-26 17:07:06'),('일이삼사','$2b$10$9KUWk.v4/sxMNm1fzgMXbeIeZKE5dQQLoNx2WYgj.L0oH4r77a3xO','전경환','uniline123@naver.com',NULL,NULL,'http://localhost:3010/uploads/1764312930576-man.png',NULL,'2025-11-26 09:53:08'),('일일일일','$2b$10$G0Dgru8Hlp99VvhiGVaVBuH5TftUIdlNFia9kswWZM.thhqzp6Qg6','테스트','01011111111',NULL,NULL,NULL,NULL,'2025-11-27 14:35:29');
/*!40000 ALTER TABLE `insta_tbl_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:08
