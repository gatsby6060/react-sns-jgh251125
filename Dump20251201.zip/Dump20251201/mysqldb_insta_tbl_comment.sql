-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_comment`
--

DROP TABLE IF EXISTS `insta_tbl_comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_comment` (
  `COMMENT_ID` int NOT NULL AUTO_INCREMENT,
  `FEED_ID` int NOT NULL,
  `USER_ID` varchar(300) NOT NULL,
  `CONTENT` text NOT NULL,
  `CREATED_AT` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`COMMENT_ID`),
  KEY `FEED_ID` (`FEED_ID`),
  KEY `USER_ID` (`USER_ID`),
  CONSTRAINT `insta_tbl_comment_ibfk_1` FOREIGN KEY (`FEED_ID`) REFERENCES `insta_tbl_feed` (`FEED_ID`),
  CONSTRAINT `insta_tbl_comment_ibfk_2` FOREIGN KEY (`USER_ID`) REFERENCES `insta_tbl_user` (`USER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_comment`
--

LOCK TABLES `insta_tbl_comment` WRITE;
/*!40000 ALTER TABLE `insta_tbl_comment` DISABLE KEYS */;
INSERT INTO `insta_tbl_comment` VALUES (1,10,'닉공일구','testing','2025-11-27 18:24:29'),(2,10,'순이1234','되나?','2025-11-28 09:44:36'),(3,10,'1q2w3e4r','되나?','2025-11-28 11:02:40'),(4,13,'일이삼사','테스트입니다.','2025-11-28 14:39:50'),(5,12,'일이삼사','ㄱㄱ','2025-11-28 15:04:30'),(6,13,'일이삼사','고기고기','2025-11-28 16:05:24'),(7,12,'일이삼사','고고','2025-11-28 16:05:48'),(8,11,'일이삼사','신발이 멋지군여','2025-11-28 16:05:57'),(9,14,'kakao_4501469156_kakao','나무작대기 타고 멀리 걸어감','2025-12-01 13:10:04'),(10,16,'kakao_4501469156_kakao','gg','2025-12-01 14:33:17'),(11,17,'kakao_4501469156_kakao','화를 잘뜨네용','2025-12-01 16:32:33');
/*!40000 ALTER TABLE `insta_tbl_comment` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:08
