-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_feed_img`
--

DROP TABLE IF EXISTS `tbl_feed_img`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_feed_img` (
  `imgNo` int NOT NULL AUTO_INCREMENT,
  `feedId` int NOT NULL,
  `imgName` varchar(255) NOT NULL,
  `imgPath` varchar(500) NOT NULL,
  PRIMARY KEY (`imgNo`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_feed_img`
--

LOCK TABLES `tbl_feed_img` WRITE;
/*!40000 ALTER TABLE `tbl_feed_img` DISABLE KEYS */;
INSERT INTO `tbl_feed_img` VALUES (1,1,'test','https://images.unsplash.com/photo-1551963831-b3b1ca40c98e'),(2,2,'test','https://images.unsplash.com/photo-1521747116042-5a810fda9664'),(3,3,'test','https://ix-marketing.imgix.net/focalpoint.png?auto=format,compress&w=1946'),(6,13,'1763969448005-RUNNERS HOUSE - Chrome 2025-11-07 10-44-57.gif','uploads/'),(7,13,'1763969448015-Nike_Brand_Ads_Poster_Running_Girl_3840x2160.jpg','uploads/'),(8,13,'1763969448017-hat.png','uploads/'),(9,14,'1763970428783-Nike_Brand_Ads_Poster_Running_Girl_3840x2160.jpg','http://localhost:3010/uploads/1763970428783-Nike_Brand_Ads_Poster_Running_Girl_3840x2160.jpg'),(10,14,'1763970428789-hat.jfif','http://localhost:3010/uploads/1763970428789-hat.jfif'),(11,15,'1764144682514-sata.png','http://localhost:3010/uploads/1764144682514-sata.png'),(12,16,'1764211347663-man.png','http://localhost:3010/uploads/1764211347663-man.png'),(13,17,'1764211493998-man.png','http://localhost:3010/uploads/1764211493998-man.png');
/*!40000 ALTER TABLE `tbl_feed_img` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:08
