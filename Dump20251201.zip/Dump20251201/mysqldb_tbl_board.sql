-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `tbl_board`
--

DROP TABLE IF EXISTS `tbl_board`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tbl_board` (
  `boardNo` int NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `contents` text NOT NULL,
  `userId` varchar(50) NOT NULL,
  `cnt` int DEFAULT '0',
  `cdatetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `udatetime` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`boardNo`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tbl_board`
--

LOCK TABLES `tbl_board` WRITE;
/*!40000 ALTER TABLE `tbl_board` DISABLE KEYS */;
INSERT INTO `tbl_board` VALUES (3,'2우1리1는 왜 이렇게 바쁠까요?','요1즘 바1쁜 일상 속에서 여유를 찾는 게 점점 더 어려워지는 것 같아요. 여러분은 어떻게 여유를 찾고 계신가요?','user003',13,'2025-04-03 11:15:00','2025-11-19 20:35:22'),(4,'하루를 마무리하며','오늘 하루가 어떻게 지나갔는지 한번 되돌아보며, 내일은 더 좋은 하루가 되기를 바래봅니다.','user004',15,'2025-04-04 13:45:00','2025-04-04 13:45:00'),(5,'새로운 시작, 새로운 도전','새로운 프로젝트를 시작했습니다! 이렇게 시작하는 게 설렙니다. 실패를 두려워하지 말자고 마음먹고 도전해보려 합니다.','user001',8,'2025-04-05 14:00:00','2025-04-05 14:00:00'),(6,'주말에는 무엇을 할까요?','주말에는 모두 무엇을 할 예정인가요? 저는 집에서 휴식을 취하며 영화를 보고 싶어요. 다들 어떻게 보내세요?','user002',12,'2025-04-06 10:10:00','2025-04-06 10:10:00'),(7,'오늘의 책 한 권','오늘 읽은 책이 정말 인상 깊었어요. 특히 그 부분이 마음에 와 닿았습니다. 여러분도 한 번 읽어보세요!','user003',20,'2025-04-07 11:45:00','2025-04-07 11:45:00'),(8,'추억 속 여행','몇 년 전에 갔던 여행지가 떠오릅니다. 그때의 즐거운 순간들이 아직도 선명하게 기억에 남아요.','user004',30,'2025-04-08 15:20:00','2025-04-08 15:20:00'),(9,'디지털 시대의 장단점','디지털 기술이 발달하면서 우리의 삶이 많이 변화했어요. 그러나 그만큼 불편함도 따르죠. 이 변화가 과연 좋은 것일까요?','user001',18,'2025-04-09 09:30:00','2025-04-09 09:30:00'),(10,'새로운 취미를 시작하다','최근에 새로운 취미를 시작했어요. 정말 재밌고 시간이 빠르게 지나가네요. 여러분도 새로 시작한 취미가 있나요?','user002',22,'2025-04-10 10:00:00','2025-04-10 10:00:00'),(11,'인생의 작은 변화','작은 변화가 인생을 크게 바꿀 수 있다는 말을 요즘 실감하고 있어요. 여러분도 그런 순간을 경험해보셨나요?','user003',14,'2025-04-11 16:00:00','2025-04-11 16:00:00'),(12,'어린 시절의 추억','어린 시절의 추억이 떠오릅니다. 그때는 아무 걱정 없이 뛰어놀았던 기억들이 아직도 생생하네요.','user004',7,'2025-04-12 12:10:00','2025-04-12 12:10:00'),(13,'행복이란 무엇일까?','행복의 의미를 잘 모르겠어요. 사람마다 다르게 정의할 수 있겠지만, 저는 그냥 작은 것에서 행복을 느끼고 싶어요.','user001',16,'2025-04-13 14:30:00','2025-04-13 14:30:00'),(14,'음악의 힘','요즘 음악이 정말 큰 힘이 돼요. 힘든 하루를 보내고 있을 때, 좋은 음악 한 곡이 모든 걸 바꿀 수 있다는 걸 느껴요.','user002',19,'2025-04-14 08:45:00','2025-04-14 08:45:00'),(15,'자기 계발의 중요성','자기 계발은 왜 중요한지, 그 이유에 대해 고민해보게 됩니다. 꾸준히 노력하며 성장해가는 것이 중요하다고 생각해요.','user003',12,'2025-04-15 10:00:00','2025-11-19 21:09:34'),(16,'1111111111111','cccccccccccccc','user001',4,'2025-11-19 20:49:50','2025-11-19 21:21:56');
/*!40000 ALTER TABLE `tbl_board` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:08
