-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_chat_room`
--

DROP TABLE IF EXISTS `insta_tbl_chat_room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_chat_room` (
  `ROOM_ID` int NOT NULL AUTO_INCREMENT COMMENT '채팅방 고유 ID',
  `USER1_ID` varchar(300) NOT NULL COMMENT '사용자 ID 1',
  `USER2_ID` varchar(300) NOT NULL COMMENT '사용자 ID 2',
  `LAST_MESSAGE_ID` int DEFAULT NULL COMMENT '마지막 메시지 ID (캐싱용)',
  `CREATED_AT` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '생성 일시',
  PRIMARY KEY (`ROOM_ID`),
  UNIQUE KEY `unique_room` (`USER1_ID`,`USER2_ID`),
  KEY `USER2_ID` (`USER2_ID`),
  CONSTRAINT `insta_tbl_chat_room_ibfk_1` FOREIGN KEY (`USER1_ID`) REFERENCES `insta_tbl_user` (`USER_ID`),
  CONSTRAINT `insta_tbl_chat_room_ibfk_2` FOREIGN KEY (`USER2_ID`) REFERENCES `insta_tbl_user` (`USER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_chat_room`
--

LOCK TABLES `insta_tbl_chat_room` WRITE;
/*!40000 ALTER TABLE `insta_tbl_chat_room` DISABLE KEYS */;
/*!40000 ALTER TABLE `insta_tbl_chat_room` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:08
