-- MySQL dump 10.13  Distrib 8.0.44, for Win64 (x86_64)
--
-- Host: localhost    Database: mysqldb
-- ------------------------------------------------------
-- Server version	8.0.44

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `insta_tbl_password_reset`
--

DROP TABLE IF EXISTS `insta_tbl_password_reset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `insta_tbl_password_reset` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` varchar(100) NOT NULL,
  `token` varchar(512) NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `token` (`token`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insta_tbl_password_reset`
--

LOCK TABLES `insta_tbl_password_reset` WRITE;
/*!40000 ALTER TABLE `insta_tbl_password_reset` DISABLE KEYS */;
INSERT INTO `insta_tbl_password_reset` VALUES (1,'일이삼사','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiLsnbzsnbTsgrzsgqwiLCJwdXJwb3NlIjoicHctcmVzZXQiLCJpYXQiOjE3NjQ1NTc4MDksImV4cCI6MTc2NDU1OTYwOX0.Du8YQSyr6lXwCsKa95WMQbs4-A2dDHZ4riU4Lp12u9M','2025-12-01 12:26:49',0,'2025-12-01 11:56:49'),(2,'일이삼사','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiLsnbzsnbTsgrzsgqwiLCJwdXJwb3NlIjoicHctcmVzZXQiLCJpYXQiOjE3NjQ1NTkxNTYsImV4cCI6MTc2NDU2MDk1Nn0.bPix52Ao7JnpQjqpSd2DJcyH1Atz8qBsM0LOsuI44lE','2025-12-01 12:49:17',0,'2025-12-01 12:19:16'),(3,'일이삼사','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiLsnbzsnbTsgrzsgqwiLCJwdXJwb3NlIjoicHctcmVzZXQiLCJpYXQiOjE3NjQ1NTkxODcsImV4cCI6MTc2NDU2MDk4N30.FVXvGW43_oLr8P4tMJyIvMBxfJkW9xMlFQH1Ges1kBM','2025-12-01 12:49:47',0,'2025-12-01 12:19:47'),(4,'일이삼사','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiLsnbzsnbTsgrzsgqwiLCJwdXJwb3NlIjoicHctcmVzZXQiLCJpYXQiOjE3NjQ1NjAwNTgsImV4cCI6MTc2NDU2MTg1OH0.LNlZ7hCoQQpmXvkpv6disd3uE5_bCBIvMW8YVESvGYY','2025-12-01 13:04:19',0,'2025-12-01 12:34:18'),(5,'일이삼사','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiLsnbzsnbTsgrzsgqwiLCJwdXJwb3NlIjoicHctcmVzZXQiLCJpYXQiOjE3NjQ1NjA0ODcsImV4cCI6MTc2NDU2MjI4N30.PQoDlSsnmyhz2kDYpnC7FF07khMzPbvTiGlbTyOb4vw','2025-12-01 13:11:27',0,'2025-12-01 12:41:27'),(6,'일이삼사','eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySWQiOiLsnbzsnbTsgrzsgqwiLCJwdXJwb3NlIjoicHctcmVzZXQiLCJpYXQiOjE3NjQ1NjA3MTQsImV4cCI6MTc2NDU2MjUxNH0.P9E79LyWlegThG2PoJ-7B_44Ke9DYY2-tT23pSwGjUs','2025-12-01 13:15:14',1,'2025-12-01 12:45:14');
/*!40000 ALTER TABLE `insta_tbl_password_reset` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-01 18:13:09
